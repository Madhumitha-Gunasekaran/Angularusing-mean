import { Component, OnInit ,ViewChild} from '@angular/core';
import {UserService}from '../user.service';
// import {User} from '../model/user';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
// import { DataSource } from '@angular/cdk/table';

export interface Userdetail{
  Name:''
  Age:''
  office:''
  Action:''
  // password:string
}

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  providers:[UserService]

})

export class HomeComponent implements OnInit {
  dataSource : MatTableDataSource<Userdetail>=new MatTableDataSource([]);
  pagelength:any;
 paginators:any;
  
  displayedColumns:string[]=['Name','Age','office','Action']


  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  
  constructor(private userService:UserService,private route:Router) { }

  ngOnInit(): void {
    this.userService.getUser().subscribe((res:Userdetail[])=>{
     
     this.dataSource.data=res;
     this.pagelength=this.dataSource.data.length;
     this.dataSource.paginator=this.paginator;
     this.dataSource.sort=this.sort;
      console.log('page length',this.pagelength);
      console.log('datasource',this.dataSource);
      console.log('datasource.data',this.dataSource.data);
    })

  }
  applyFilter(value:string){
   this.paginators= this.dataSource.filter=value.trim().toLocaleUpperCase();
    console.log('hello',this.dataSource.filter);
        }
  
        editEmployee(empid){

        }
}

