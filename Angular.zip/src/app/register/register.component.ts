import { Component, OnInit } from '@angular/core';
import {UserService}from '../user.service';
import {User} from '../model/user';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
  providers:[UserService]
})
export class RegisterComponent implements OnInit {
  hide=true;
  reguser:any=[];
  saveForm:any=[];
  model=new User();

  constructor(private userService:UserService,private route:Router) { }

  ngOnInit(): void {
    this.userService.getUser().subscribe(res=>{
      this.reguser=res;
      console.log('emloyee',this.reguser)
    })
  }
  onSubmit(form:NgForm){
    this.userService.postUser(form.value).subscribe(res=>{
      this.saveForm=res;
      console.log(this.saveForm);
      this.route.navigate(['./login']);

    })

  }


}
