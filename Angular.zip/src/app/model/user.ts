export class User {
    Name:String
    Age:String
    office:String
    password:String
}
